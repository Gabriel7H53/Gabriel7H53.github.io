/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package interfaces;

import entidade.Pneus;
import entidade.Pneus.marca_pneus;
import entidade.Pneus.qtd_pneus;
import javax.swing.DefaultComboBoxModel;
/**
 *
 * @author Gahen
 */
public class PainelServicoPneus extends javax.swing.JPanel {

    public PainelServicoPneus() {
        initComponents();
        limparCampos();   
    }
    
     public marca_pneus getSelectedmarcaPneus(){
        Object marcaPneus = pneus_cadastradosComboBox.getSelectedItem();
        if(marcaPneus != null) return (marca_pneus)marcaPneus;
        else return null;
    }
    public void setSelectedmarcaPneus(marca_pneus marcaPneus){
        pneus_cadastradosComboBox.setSelectedItem(marcaPneus);
    }
    
    public qtd_pneus getSelectedqtd_pneus(){
        qtd_pneus qtdPneus = null;
        if (quantidadebuttonGroup.getSelection() != null)
            qtdPneus = qtd_pneus.values()[quantidadebuttonGroup.getSelection().getMnemonic()];
        return qtdPneus;
    }
    
    public void setSelectedquantidade(int indice_quantidade){
        switch(indice_quantidade){
            case 0: doisRadioButton.setSelected(true);break;
            case 1: quatroRadioButton.setSelected(true);
        }
    }
      
    public boolean isBalanceamento() {
        return balanceamentoCheckBox.isSelected();
    }

    public void setBalanceamento(boolean balanceamento) {
        balanceamentoCheckBox.setSelected(balanceamento);
    }

    public boolean isAlinhamento() {
        return alinhamentoCheckBox.isSelected();
    }

    public void setAlinhamento(boolean alinhamento) {
        alinhamentoCheckBox.setSelected(alinhamento);
    }
    
    
    public void limparCampos(){
        balanceamentoCheckBox.setSelected(false);
        alinhamentoCheckBox.setSelected(false);
        pneus_cadastradosComboBox.setSelectedIndex(-1);
        quantidadebuttonGroup.clearSelection();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        quantidadebuttonGroup = new javax.swing.ButtonGroup();
        marca_pneusLabel = new javax.swing.JLabel();
        alinhamentoCheckBox = new javax.swing.JCheckBox();
        balanceamentoCheckBox = new javax.swing.JCheckBox();
        pneus_cadastradosComboBox = new javax.swing.JComboBox();
        quantidadeLabel = new javax.swing.JLabel();
        doisRadioButton = new javax.swing.JRadioButton();
        quatroRadioButton = new javax.swing.JRadioButton();

        marca_pneusLabel.setText("Marca Novos Pneus:");

        alinhamentoCheckBox.setText("Alinhamento");
        alinhamentoCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alinhamentoCheckBoxActionPerformed(evt);
            }
        });

        balanceamentoCheckBox.setText("Balanceamento");
        balanceamentoCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                balanceamentoCheckBox1ActionPerformed(evt);
            }
        });

        pneus_cadastradosComboBox.setModel(new DefaultComboBoxModel (marca_pneus.values()));

        quantidadeLabel.setText("Quantidade");

        quantidadebuttonGroup.add(doisRadioButton);
        doisRadioButton.setText("Dois");
        doisRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doisRadioButtonActionPerformed(evt);
            }
        });

        quantidadebuttonGroup.add(quatroRadioButton);
        quatroRadioButton.setMnemonic('\u0001');
        quatroRadioButton.setText("Quatro");
        quatroRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quatroRadioButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(alinhamentoCheckBox)
                    .addComponent(balanceamentoCheckBox)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(quantidadeLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(doisRadioButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(quatroRadioButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(150, 150, 150))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(marca_pneusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pneus_cadastradosComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(73, 73, 73))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(marca_pneusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pneus_cadastradosComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(doisRadioButton)
                    .addComponent(quatroRadioButton)
                    .addComponent(quantidadeLabel))
                .addGap(10, 10, 10)
                .addComponent(balanceamentoCheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(alinhamentoCheckBox)
                .addContainerGap(126, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void alinhamentoCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alinhamentoCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alinhamentoCheckBoxActionPerformed

    private void balanceamentoCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_balanceamentoCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_balanceamentoCheckBox1ActionPerformed

    private void doisRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doisRadioButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_doisRadioButtonActionPerformed

    private void quatroRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quatroRadioButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quatroRadioButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox alinhamentoCheckBox;
    private javax.swing.JCheckBox balanceamentoCheckBox;
    private javax.swing.JRadioButton doisRadioButton;
    private javax.swing.JLabel marca_pneusLabel;
    private javax.swing.JComboBox pneus_cadastradosComboBox;
    private javax.swing.JLabel quantidadeLabel;
    private javax.swing.ButtonGroup quantidadebuttonGroup;
    private javax.swing.JRadioButton quatroRadioButton;
    // End of variables declaration//GEN-END:variables
}
