/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package interfaces;

import entidade.Motor.componente_reparado;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author Gahen
 */
public class PainelFiltrosServicoMotor extends javax.swing.JPanel {

    /**
     * Creates new form PainelServicoReparoMotor
     */
    public PainelFiltrosServicoMotor() {
        initComponents();
        limparCampos();
    }

    public componente_reparado getSelectedcomponente_reparado() {
        Object componenteReparado = componente_reparadoComboBox.getSelectedItem();
        if (componenteReparado != null) {
            return (componente_reparado) componenteReparado;
        } else {
            return null;
        }
    }

    public void setSelectedcomponente_reparado(componente_reparado componenteReparado) {
        componente_reparadoComboBox.setSelectedItem(componenteReparado);
    }

    public void limparCampos() {
        componente_reparadoComboBox.setSelectedIndex(-1);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        componente_reparadoLabel = new javax.swing.JLabel();
        componente_reparadoComboBox = new javax.swing.JComboBox();

        componente_reparadoLabel.setText("Componente Reparado:");

        componente_reparadoComboBox.setModel(new DefaultComboBoxModel (componente_reparado.values()));
        componente_reparadoComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                componente_reparadoComboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(componente_reparadoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(componente_reparadoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(componente_reparadoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(componente_reparadoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void componente_reparadoComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_componente_reparadoComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_componente_reparadoComboBoxActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox componente_reparadoComboBox;
    private javax.swing.JLabel componente_reparadoLabel;
    // End of variables declaration//GEN-END:variables
}
