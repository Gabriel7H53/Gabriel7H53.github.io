DROP TABLE IF EXISTS clientes; 
 
CREATE TABLE clientes ( 
    Cpf VARCHAR(60) NOT NULL, 
    Telefone VARCHAR(60) NOT NULL, 
    Nome VARCHAR(60) NOT NULL); 
